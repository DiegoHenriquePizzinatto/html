$ativos = [
  'PETR4.SA', 'VALE3.SA', 'ITUB4.SA', // Ações
  'HGLG11.SA', 'KNRI11.SA', 'MXRF11.SA' // FIIs
];
