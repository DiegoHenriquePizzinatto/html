<?php
define('RAPIDAPI_KEY', 'd84ae7b977mshdf433c463683aa1p1e80cdjsn0480fcf60283');
define('DB_HOST', 'localhost');
define('DB_NAME', 'painel');
define('DB_USER', 'pizzinattod');
define('DB_PASS', 'S1st3m3m');
session_start();