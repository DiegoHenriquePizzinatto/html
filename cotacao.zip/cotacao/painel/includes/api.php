<?php
function buscarCotacoesYahoo($symbols, $apiKey) {
    $host = 'https://apidojo-yahoo-finance-v1.p.rapidapi.com/market/v2/get-quotes';
    $query = http_build_query(['symbols' => implode(',', $symbols), 'region' => 'BR']);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => "$host?$query",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'X-RapidAPI-Host: apidojo-yahoo-finance-v1.p.rapidapi.com',
            'X-RapidAPI-Key: ' . $apiKey
        ]
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($response, true);
    return $json['quoteResponse']['result'] ?? [];
}