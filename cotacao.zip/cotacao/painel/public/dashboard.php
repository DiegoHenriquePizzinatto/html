<?php
require_once '../config/db.php';
require_once '../includes/api.php';
if (!$_SESSION['logado']) exit('Acesso negado');

$ativos = ['PETR4.SA','VALE3.SA','MXRF11.SA'];
$cotacoes = buscarCotacoesYahoo($ativos, RAPIDAPI_KEY);
?>
<h1>Cotações</h1>
<a href="exportar.php">Exportar CSV</a> | <a href="alertas.php">Ver alertas</a>
<table border=1>
<tr><th>Ativo</th><th>Preço</th><th>Variação (%)</th></tr>
<?php foreach ($cotacoes as $c): ?>
<tr>
<td><?= $c['symbol'] ?></td>
<td><?= number_format($c['regularMarketPrice'], 2, ',', '.') ?></td>
<td><?= number_format($c['regularMarketChangePercent'], 2, ',', '.') ?>%</td>
</tr>
<?php endforeach ?>
</table>