<?php
require_once '../config/db.php';
require_once '../includes/api.php';
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=cotacoes.csv');

$ativos = ['PETR4.SA','VALE3.SA','MXRF11.SA'];
$data = buscarCotacoesYahoo($ativos, RAPIDAPI_KEY);

$output = fopen('php://output', 'w');
fputcsv($output, ['Ativo', 'Preço', 'Variação']);
foreach ($data as $row) {
    fputcsv($output, [$row['symbol'], $row['regularMarketPrice'], $row['regularMarketChangePercent']]);
}
fclose($output);