<?php
require_once '../config/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? AND senha = ?");
    $stmt->execute([$_POST['email'], md5($_POST['senha'])]);
    if ($stmt->rowCount()) {
        $_SESSION['logado'] = true;
        header('Location: dashboard.php');
        exit;
    } else {
        $erro = "Login inválido";
    }
}
?>
<form method="post">
    <input name="email" placeholder="Email"><br>
    <input name="senha" type="password" placeholder="Senha"><br>
    <button>Entrar</button>
    <?php if (!empty($erro)) echo "<p>$erro</p>"; ?>
</form>