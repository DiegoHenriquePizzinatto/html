<?php
require_once '../config/db.php';
if (!$_SESSION['logado']) exit('Acesso negado');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO alertas (symbol, preco, email) VALUES (?, ?, ?)");
    $stmt->execute([$_POST['symbol'], $_POST['preco'], $_POST['email']]);
}
$alertas = $pdo->query("SELECT * FROM alertas")->fetchAll(PDO::FETCH_ASSOC);
?>
<h1>Alertas</h1>
<form method="post">
    Ativo: <input name="symbol"><br>
    Preço Alvo: <input name="preco"><br>
    Email: <input name="email"><br>
    <button>Salvar Alerta</button>
</form>
<table border=1>
<tr><th>Ativo</th><th>Preço</th><th>Email</th></tr>
<?php foreach ($alertas as $a): ?>
<tr><td><?= $a['symbol'] ?></td><td><?= $a['preco'] ?></td><td><?= $a['email'] ?></td></tr>
<?php endforeach ?>
</table>