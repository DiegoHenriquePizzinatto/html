CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    senha VARCHAR(32) NOT NULL
);
INSERT INTO usuarios (email, senha) VALUES ('admin@admin.com', MD5('1234'));

CREATE TABLE alertas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    symbol VARCHAR(10),
    preco DECIMAL(10,2),
    email VARCHAR(100)
);