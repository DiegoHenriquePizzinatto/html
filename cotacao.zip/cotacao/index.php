<?php
function getYahooRapidAPI($symbols) {
    $host = 'https://apidojo-yahoo-finance-v1.p.rapidapi.com/market/v2/get-quotes';
    $query = http_build_query([
        'symbols' => implode(',', $symbols),
        'region' => 'BR'
    ]);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => "$host?$query",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'X-RapidAPI-Host: apidojo-yahoo-finance-v1.p.rapidapi.com',
            'X-RapidAPI-Key: d84ae7b977mshdf433c463683aa1p1e80cdjsn0480fcf60283' // Substitua aqui
        ]
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo "Erro CURL: " . curl_error($ch);
        return [];
    }
    curl_close($ch);

    $json = json_decode($response, true);
    return $json['quoteResponse']['result'] ?? [];
}

$ativos = [
    'PETR4.SA', 'VALE3.SA', 'ITUB4.SA',
    'MXRF11.SA', 'HGLG11.SA', 'KNRI11.SA'
];

$cotacoes = getYahooRapidAPI($ativos);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>📈 Cotações Yahoo Finance</title>
  <style>
    body {
      background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 20px;
      color: #fff;
    }

    .glass {
      background: rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
      backdrop-filter: blur(10px);
      padding: 20px;
      max-width: 1000px;
      margin: auto;
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    input[type="text"] {
      width: 100%;
      padding: 12px;
      border-radius: 10px;
      border: none;
      font-size: 16px;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 12px;
      text-align: left;
    }

    th {
      background-color: rgba(255, 255, 255, 0.2);
    }

    tr:nth-child(even) {
      background-color: rgba(255, 255, 255, 0.05);
    }

    .positivo {
      color: #4caf50;
    }

    .negativo {
      color: #f44336;
    }
  </style>
</head>
<body>
  <div class="glass">
    <h1>📊 Cotações de Ações e FIIs</h1>
    <input type="text" id="filtro" placeholder="Filtrar ativos...">

    <table>
      <thead>
        <tr>
          <th>Ativo</th>
          <th>Nome</th>
          <th>Preço</th>
          <th>Variação (%)</th>
        </tr>
      </thead>
      <tbody id="tabela">
        <?php foreach ($cotacoes as $item): ?>
          <tr>
            <td><?= htmlspecialchars($item['symbol']) ?></td>
            <td><?= htmlspecialchars($item['shortName'] ?? '-') ?></td>
            <td>R$ <?= number_format($item['regularMarketPrice'] ?? 0, 2, ',', '.') ?></td>
            <td class="<?= ($item['regularMarketChangePercent'] ?? 0) >= 0 ? 'positivo' : 'negativo' ?>">
              <?= number_format($item['regularMarketChangePercent'] ?? 0, 2, ',', '.') ?>%
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <script>
    const filtro = document.getElementById('filtro');
    filtro.addEventListener('input', () => {
      const termo = filtro.value.toLowerCase();
      document.querySelectorAll('#tabela tr').forEach(tr => {
        const visivel = tr.innerText.toLowerCase().includes(termo);
        tr.style.display = visivel ? '' : 'none';
      });
    });
  </script>
</body>
</html>
