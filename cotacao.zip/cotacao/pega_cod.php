<?php
// Endpoint oficial da B3 (público, não documentado)
$url = 'https://sistemaswebb3-listados.b3.com.br/listedCompaniesProxy/CompanyCall/GetInitialCompanies/';

// Configurações da requisição POST
$options = [
    'http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: application/json",
        'content' => '{}'
    ]
];

$context = stream_context_create($options);

// Faz a requisição
$response = file_get_contents($url, false, $context);

// Verifica se a resposta veio corretamente
if ($response === false) {
    die("Erro ao acessar os dados da B3.");
}

// Decodifica o JSON retornado
$data = json_decode($response, true);

// Extrai os símbolos
if (isset($data['companies'])) {
    $ativos = array_map(function($empresa) {
        return $empresa['code'];
    }, $data['companies']);

    // Remove duplicados e ordena
    $ativos = array_unique($ativos);
    sort($ativos);

    // Exibe os códigos
    foreach ($ativos as $codigo) {
        echo $codigo . PHP_EOL;
    }

    // Ou salva em um arquivo
    // file_put_contents("ativos_b3.txt", implode(PHP_EOL, $ativos));

} else {
    echo "Formato de dados inesperado.";
}
